#!/system/bin/sh
# Magisk post-fs-data script

MODDIR=${0%/*}
