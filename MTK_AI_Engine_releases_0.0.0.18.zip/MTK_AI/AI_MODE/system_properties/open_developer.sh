#!/system/bin/sh
#!/data/adb/modules/MTK_AI/busybox sh

LOG_FILE="/sdcard/MTK_AI_Engine/MTK_AI_Engine.log"

log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

set -e  # Exit on error

if [ "$(id -u)" != "0" ]; then
  log_msg "❌ Not running as root!" >&2
  exit 1
fi

# Enable Dev Options
settings put global development_settings_enabled 1
settings put global adb_enabled 1 2>/dev/null || true

# Optional: Trigger 7-tap (simulate)
# settings put global development_settings_enabled 1

log_msg "✅ Developer Options enabled (uid=$(id -u))"