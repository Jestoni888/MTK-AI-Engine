#!/system/bin/sh

# Define the target directory
TARGET_DIR="/sdcard/MTK_AI_Engine"

# List of filenames to check
FILES=("enable_touch1" "enable_touch2")

for FILE_NAME in "${FILES[@]}"; do
    FILE_PATH="$TARGET_DIR/$FILE_NAME"

    # Check if the file exists and is not a directory
    if [ -f "$FILE_PATH" ]; then
        echo "Found: $FILE_NAME. Renaming to $FILE_NAME.exec"
        mv "$FILE_PATH" "$FILE_PATH.exec"
    else
        echo "Skipping: $FILE_NAME (Not found in $TARGET_DIR)"
    fi
done
