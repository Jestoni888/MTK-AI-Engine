#!/system/bin/sh

LOG_DIR="/sdcard/MTK_AI_Engine"
LOG_FILE="$LOG_DIR/MTK_AI_Engine.log"
mkdir -p "$LOG_DIR"

log() {
    echo "[$(date '+%H:%M:%S')] $1" >> "$LOG_FILE"
}

log "🔥 HARDCORE GAMING MODE INIT"
su -c settings put global development_settings_enabled 1

sleep 2
# --------------------------------------------------
# GRAPHICS PIPELINE (SurfaceFlinger / HWUI)
# --------------------------------------------------
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.high_fps_late_app_phase_offset_ns 0
setprop debug.sf.high_fps_early_phase_offset_ns 0
setprop debug.sf.high_fps_early_gl_phase_offset_ns 0
setprop debug.sf.early_phase_offset_ns 0
setprop debug.sf.early_gl_phase_offset_ns 0

setprop debug.hwui.render_ahead 1
setprop debug.hwui.disable_vsync true
setprop debug.hwui.use_buffer_age false
setprop debug.hwui.profile false

log "🎮 SurfaceFlinger & HWUI unlocked"

# --------------------------------------------------
# GPU PATH (AGGRESSIVE)
# --------------------------------------------------
setprop debug.egl.force_msaa true
setprop debug.egl.hw 1
setprop debug.egl.swapinterval -1
setprop debug.gr.swapinterval -1

log "🖥 GPU pipeline forced"

# --------------------------------------------------
# CPU / SCHEDULER BIAS
# --------------------------------------------------
setprop sched.colocate.enable 1
setprop sched.colocate.affinity 1
setprop sched.prefer_idle.enable 0
setprop sched.upmigrate 90
setprop sched.downmigrate 85

setprop debug.cpurendering true

log "⚡ Scheduler biased for foreground load"

# --------------------------------------------------
# FRAME LIMIT / VSYNC RELAX
# --------------------------------------------------
setprop persist.sys.framepredict.enable false
setprop persist.sys.sf.disable_idle_timer 1
setprop persist.sys.sf.set_idle_timer_ms 0

log "🚫 Frame limiter relaxed"

# --------------------------------------------------
# MEDIATEK / DISPLAY (SAFE NO-OP IF UNSUPPORTED)
# --------------------------------------------------
setprop persist.sys.miravision.vivid.mode 3
setprop persist.sys.force_vivid 1
setprop persist.sys.ui.hw true

log "📱 Display pipeline forced"

# --------------------------------------------------
# SURFACEFLINGER BOOST (ASYNC)
# --------------------------------------------------
(
    service call SurfaceFlinger 1008 i32 1 >/dev/null 2>&1
    log "🚀 SurfaceFlinger BOOST 1008 fired"
) &

log "🔥 HARDCORE GAMING MODE ACTIVE"
exit 0
