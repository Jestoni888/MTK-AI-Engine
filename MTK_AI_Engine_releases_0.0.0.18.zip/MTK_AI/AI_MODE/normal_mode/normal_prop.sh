#!/system/bin/sh
#!/data/adb/modules/MTK_AI/busybox sh

LOG_FILE="/sdcard/MTK_AI_Engine/MTK_AI_Engine.log"

log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}
#Deactivating developer options to save battery
su -c settings put global development_settings_enabled 0
sleep 5

# 1. Apply Properties (Fast)
setprop debug.hwui.render_ahead 0
setprop persist.sys.miravision.vivid.mode 0
setprop persist.sys.force_vivid 0
setprop persist.sys.framepredict.enable false
setprop debug.sf.latch_unsignaled false
setprop debug.cpurendering false
setprop debug.egl.force_msaa false
setprop persist.sys.ui.hw true
setprop persist.sys.use_dithering 0
setprop debug.sf.early_phase_offset_ns 0
setprop debug.sf.early_gl_phase_offset_ns 0
setprop debug.sf.high_fps_early_phase_offset_ns 0
setprop debug.sf.high_fps_early_gl_phase_offset_ns 0

# 2. Non-blocking SurfaceFlinger Call
# We remove the loop and the sleep. We call it once.
# If it's a "normal mode" script, the system is already up.

    # Running this in a subshell ( ) & prevents the main engine from waiting
    service call SurfaceFlinger 1008 i32 0 >/dev/null 2>&1
        
    log_msg "🟢 NORMAL MODE PROPS applied (SF 1008 called)"
 
