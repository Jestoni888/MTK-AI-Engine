#!/system/bin/sh

# Define the target directory
TARGET_DIR="/sdcard/MTK_AI_Engine"

# List of files to restore
FILES=("enable_touch1" "enable_touch2")

for FILE_NAME in "${FILES[@]}"; do
    FILE_WITH_EXT="$TARGET_DIR/$FILE_NAME.exec"
    ORIGINAL_PATH="$TARGET_DIR/$FILE_NAME"

    if [ -f "$FILE_WITH_EXT" ]; then
        echo "Found: $FILE_NAME.exec. Renaming now..."
        mv "$FILE_WITH_EXT" "$ORIGINAL_PATH"
        
        echo "Renamed $FILE_NAME. Waiting 1 second before finishing..."
        sleep 1
        
        # This stops the loop here, so it won't check for enable_touch2
        break
    else
        echo "$FILE_NAME.exec not found, checking next..."
    fi
done

echo "Script execution finished."
