#!/system/bin/sh
### ==== FLOOD GUARD BEGIN ==== ###

SCRIPT_NAME="$(basename "$0")"
STATE_DIR="/data/adb/modules/MTK_AI/.guard"
mkdir -p "$STATE_DIR"

RUN_TS_FILE="$STATE_DIR/${SCRIPT_NAME}.last"
COUNT_FILE="$STATE_DIR/${SCRIPT_NAME}.count"

NOW=$(date +%s)
LAST=$(cat "$RUN_TS_FILE" 2>/dev/null || echo 0)
COUNT=$(cat "$COUNT_FILE" 2>/dev/null || echo 0)

# --- rate limits ---
MIN_INTERVAL=5      # seconds between runs
MAX_RUNS=5          # max runs per minute
WINDOW=60

# Too soon? exit silently
[ $((NOW - LAST)) -lt $MIN_INTERVAL ] && exit 0

# Count runs in window
if [ $((NOW - LAST)) -lt $WINDOW ]; then
  COUNT=$((COUNT + 1))
else
  COUNT=1
fi

# Too many executions? hard stop
if [ "$COUNT" -gt "$MAX_RUNS" ]; then
  echo "[FLOOD-GUARD] $SCRIPT_NAME blocked" \
    >> /sdcard/MTK_AI_Engine/flood_guard.log
  exit 0
fi

echo "$NOW" > "$RUN_TS_FILE"
echo "$COUNT" > "$COUNT_FILE"

### ==== FLOOD GUARD END ==== ###

# Target cores 4 through 7
CORES="4 5 6 7"
GOVERNOR="performance"

echo "Setting cores $CORES to $GOVERNOR..."

for CORE in $CORES; do
    PATH_GOV="/sys/devices/system/cpu/cpu$CORE/cpufreq/scaling_governor"
    
    if [ -f "$PATH_GOV" ]; then
        # Change permissions to ensure write access
        chmod 644 "$PATH_GOV"
        echo "$GOVERNOR" > "$PATH_GOV"
        echo "Core $CORE updated."
    else
        echo "Core $CORE scaling governor path not found."
    fi
done

echo "Done."
