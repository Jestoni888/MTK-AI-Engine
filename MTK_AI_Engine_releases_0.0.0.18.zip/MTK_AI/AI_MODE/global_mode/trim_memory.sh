#!/system/bin/sh
### ==== FLOOD GUARD BEGIN ==== ###

SCRIPT_NAME="$(basename "$0")"
STATE_DIR="/data/adb/modules/MTK_AI/.guard"
mkdir -p "$STATE_DIR"

RUN_TS_FILE="$STATE_DIR/${SCRIPT_NAME}.last"
COUNT_FILE="$STATE_DIR/${SCRIPT_NAME}.count"

NOW=$(date +%s)
LAST=$(cat "$RUN_TS_FILE" 2>/dev/null || echo 0)
COUNT=$(cat "$COUNT_FILE" 2>/dev/null || echo 0)

# --- rate limits ---
MIN_INTERVAL=5      # seconds between runs
MAX_RUNS=5          # max runs per minute
WINDOW=60

# Too soon? exit silently
[ $((NOW - LAST)) -lt $MIN_INTERVAL ] && exit 0

# Count runs in window
if [ $((NOW - LAST)) -lt $WINDOW ]; then
  COUNT=$((COUNT + 1))
else
  COUNT=1
fi

# Too many executions? hard stop
if [ "$COUNT" -gt "$MAX_RUNS" ]; then
  echo "[FLOOD-GUARD] $SCRIPT_NAME blocked" \
    >> /sdcard/MTK_AI_Engine/flood_guard.log
  exit 0
fi

echo "$NOW" > "$RUN_TS_FILE"
echo "$COUNT" > "$COUNT_FILE"

### ==== FLOOD GUARD END ==== ###

LOG_FILE="/sdcard/MTK_AI_Engine/MTK_AI_Engine.log"
RAM_THRESHOLD=50

log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}
# 1. Get ONLY packages that are currently running
# 'ps' lists processes, 'grep' finds the package names
RUNNING_PKGS=$(ps -A | awk '{print $9}' | grep "\." | sort -u)

# 2. Loop through and trim only those
for pkg in $RUNNING_PKGS; do
    # Skip system-critical processes that might cause crashes if forced to trim
    if [[ "$pkg" == *"com.android.systemui"* || "$pkg" == *"com.android.launcher"* ]]; then
        continue
    fi

    log_msg "Trimming Running App: $pkg"
    # Use RUNNING_CRITICAL for apps currently in use/foreground
    # Use COMPLETE for apps that might be in the background
    pm trim-caches 999G
    am send-trim-memory "$pkg" RUNNING_CRITICAL 2>/dev/null
done
