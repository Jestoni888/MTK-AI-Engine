#!/system/bin/sh
#!/data/adb/modules/MTK_AI/busybox sh

#Sync min and max frequencies to the hardware maximum
for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
    # Read the absolute maximum the hardware supports
    MAX_FREQ=$(cat "$cpu/cpufreq/cpuinfo_max_freq")
    
    # Apply it to both the current min and max limits
    echo "$MAX_FREQ" > "$cpu/cpufreq/scaling_min_freq"
    echo "$MAX_FREQ" > "$cpu/cpufreq/scaling_max_freq"
done