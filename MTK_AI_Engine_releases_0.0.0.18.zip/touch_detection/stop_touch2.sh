#!/system/bin/sh
#!/data/adb/modules/MTK_AI/busybox sh

pkill -f touch2.sh