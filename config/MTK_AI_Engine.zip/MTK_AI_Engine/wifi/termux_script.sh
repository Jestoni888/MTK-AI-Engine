#!/system/bin/sh
export HOME=/data/data/com.termux/files/home; export PREFIX=/data/data/com.termux/files/usr; export LD_PRELOAD=/data/data/com.termux/files/usr/lib/libtermux-exec.so; export PATH=$PREFIX/bin:$PATH; export TMPDIR=$PREFIX/tmp; export LANG=en_US.UTF-8; 
cd ~/wipwn && sudo python3 -u main.py -i wlan0 -b 3E:86:9A:A8:D2:14 -K > /sdcard/MTK_AI_Engine/wifi/wipwn.log 2>&1
