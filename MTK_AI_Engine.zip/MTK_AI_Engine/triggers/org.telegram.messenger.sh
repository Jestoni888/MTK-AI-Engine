#!/system/bin/sh
# Auto-generated for: org.telegram.messenger

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: org.telegram.messenger"
