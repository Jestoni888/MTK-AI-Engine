#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.newcall
echo "🔋 Powersaving: com.newcall"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.newcall"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.newcall"
