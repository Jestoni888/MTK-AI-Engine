#!/system/bin/sh
# Auto-generated for: com.android.systemui.overlay.fingerprint.anim.halo

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.android.systemui.overlay.fingerprint.anim.halo"
