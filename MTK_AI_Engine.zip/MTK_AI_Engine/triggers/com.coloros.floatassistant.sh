#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.coloros.floatassistant
echo "🔋 Powersaving: com.coloros.floatassistant"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.coloros.floatassistant"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.coloros.floatassistant"
