#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.google.ar.core
echo "🔋 Powersaving: com.google.ar.core"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.google.ar.core"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.google.ar.core"
