#!/system/bin/sh
# Auto-generated for: com.oplus.framework_bluetooth.overlay

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oplus.framework_bluetooth.overlay"
