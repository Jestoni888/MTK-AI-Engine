#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.anydesk.anydeskandroid
echo "🔋 Powersaving: com.anydesk.anydeskandroid"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.anydesk.anydeskandroid"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.anydesk.anydeskandroid"
