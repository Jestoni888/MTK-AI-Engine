#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.android.cameraextensions
echo "🔋 Powersaving: com.android.cameraextensions"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.android.cameraextensions"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.android.cameraextensions"
