#!/system/bin/sh
# Auto-generated for: com.android.networkstack.tethering.overlay

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.android.networkstack.tethering.overlay"
