#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.oplus.camera
echo "🔋 Powersaving: com.oplus.camera"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.oplus.camera"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oplus.camera"
