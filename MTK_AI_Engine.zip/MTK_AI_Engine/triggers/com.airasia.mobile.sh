#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.airasia.mobile
echo "🔋 Powersaving: com.airasia.mobile"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.airasia.mobile"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.airasia.mobile"
