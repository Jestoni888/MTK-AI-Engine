#!/system/bin/sh
# Auto-generated for: com.android.bluetooth.oplus.overlay

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.android.bluetooth.oplus.overlay"
