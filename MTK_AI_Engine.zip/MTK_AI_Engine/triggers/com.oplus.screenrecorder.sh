#!/system/bin/sh
# Auto-generated for: com.oplus.screenrecorder

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oplus.screenrecorder"
