#!/system/bin/sh
# Auto-generated for: com.oplus.owork

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oplus.owork"
