#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.gombosdev.ampere
echo "🔋 Powersaving: com.gombosdev.ampere"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.gombosdev.ampere"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.gombosdev.ampere"
