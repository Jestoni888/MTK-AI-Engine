#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.android.chrome
echo "🔋 Powersaving: com.android.chrome"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.android.chrome"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.android.chrome"
