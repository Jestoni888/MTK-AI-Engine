#!/system/bin/sh
# Auto-generated for: com.android.internal.systemui.navbar.gestural

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.android.internal.systemui.navbar.gestural"
