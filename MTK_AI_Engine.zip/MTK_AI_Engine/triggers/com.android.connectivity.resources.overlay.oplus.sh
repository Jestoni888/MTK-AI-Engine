#!/system/bin/sh
# Auto-generated for: com.android.connectivity.resources.overlay.oplus

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.android.connectivity.resources.overlay.oplus"
