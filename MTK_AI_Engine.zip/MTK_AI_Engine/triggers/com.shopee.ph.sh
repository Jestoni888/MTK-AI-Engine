#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.shopee.ph
echo "🔋 Powersaving: com.shopee.ph"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.shopee.ph"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.shopee.ph"
