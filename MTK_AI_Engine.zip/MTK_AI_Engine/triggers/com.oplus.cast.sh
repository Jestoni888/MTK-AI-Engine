#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.oplus.cast
echo "🔋 Powersaving: com.oplus.cast"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.oplus.cast"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oplus.cast"
