#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.android.captiveportallogin
echo "🔋 Powersaving: com.android.captiveportallogin"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.android.captiveportallogin"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.android.captiveportallogin"
