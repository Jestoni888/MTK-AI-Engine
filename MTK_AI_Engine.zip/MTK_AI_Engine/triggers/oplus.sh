#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: oplus
echo "🔋 Powersaving: oplus"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: oplus"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: oplus"
