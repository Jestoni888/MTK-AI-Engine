#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.oplus.blacklistapp
echo "🔋 Powersaving: com.oplus.blacklistapp"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.oplus.blacklistapp"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oplus.blacklistapp"
