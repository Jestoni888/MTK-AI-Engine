#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.mobile.legends
echo "🔋 Powersaving: com.mobile.legends"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.mobile.legends"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.mobile.legends"
