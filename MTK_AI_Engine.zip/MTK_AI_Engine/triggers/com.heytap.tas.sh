#!/system/bin/sh
# Auto-generated for: com.heytap.tas

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.heytap.tas"
