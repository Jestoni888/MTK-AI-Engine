#!/system/bin/sh
# Auto-generated for: com.transsion.camera

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.transsion.camera"
