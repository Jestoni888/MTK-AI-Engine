#!/system/bin/sh
# Auto-generated for: com.coloros.compass2

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.coloros.compass2"
