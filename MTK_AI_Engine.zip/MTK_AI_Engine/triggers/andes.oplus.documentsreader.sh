#!/system/bin/sh
# Auto-generated for: andes.oplus.documentsreader

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: andes.oplus.documentsreader"
