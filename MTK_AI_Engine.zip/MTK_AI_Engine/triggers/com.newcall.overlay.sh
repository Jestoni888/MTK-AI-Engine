#!/system/bin/sh
# Auto-generated for: com.newcall.overlay

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.newcall.overlay"
