#!/system/bin/sh
# Auto-generated for: com.oplus.sandbox.runtime

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oplus.sandbox.runtime"
