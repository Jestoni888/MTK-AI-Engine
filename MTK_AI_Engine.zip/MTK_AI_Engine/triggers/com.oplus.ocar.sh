#!/system/bin/sh
# Auto-generated for: com.oplus.ocar

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oplus.ocar"
