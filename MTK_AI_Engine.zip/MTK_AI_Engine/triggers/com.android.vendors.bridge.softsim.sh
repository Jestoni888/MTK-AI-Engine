#!/system/bin/sh
# Auto-generated for: com.android.vendors.bridge.softsim

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.android.vendors.bridge.softsim"
