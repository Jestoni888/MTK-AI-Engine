#!/system/bin/sh
# Auto-generated for: com.oplus.subsys

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oplus.subsys"
