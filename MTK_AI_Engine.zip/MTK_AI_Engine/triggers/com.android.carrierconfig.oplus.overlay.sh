#!/system/bin/sh
# Auto-generated for: com.android.carrierconfig.oplus.overlay

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.android.carrierconfig.oplus.overlay"
