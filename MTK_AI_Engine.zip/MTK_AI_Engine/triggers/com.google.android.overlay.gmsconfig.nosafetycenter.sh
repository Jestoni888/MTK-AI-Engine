#!/system/bin/sh
# Auto-generated for: com.google.android.overlay.gmsconfig.nosafetycenter

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.google.android.overlay.gmsconfig.nosafetycenter"
