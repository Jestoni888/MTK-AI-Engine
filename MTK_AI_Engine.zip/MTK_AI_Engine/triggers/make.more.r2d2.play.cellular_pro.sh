#!/system/bin/sh
# Auto-generated for: make.more.r2d2.play.cellular_pro

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: make.more.r2d2.play.cellular_pro"
