#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.heytap.opluscarlink
echo "🔋 Powersaving: com.heytap.opluscarlink"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.heytap.opluscarlink"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.heytap.opluscarlink"
