#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.oplus.olc
echo "🔋 Powersaving: com.oplus.olc"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.oplus.olc"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oplus.olc"
