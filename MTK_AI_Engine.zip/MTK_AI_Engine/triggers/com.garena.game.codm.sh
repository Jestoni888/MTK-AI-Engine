#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.garena.game.codm
echo "🔋 Powersaving: com.garena.game.codm"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.garena.game.codm"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.garena.game.codm"
