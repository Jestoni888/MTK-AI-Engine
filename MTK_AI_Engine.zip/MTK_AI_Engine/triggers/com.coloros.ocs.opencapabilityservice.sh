#!/system/bin/sh
# Auto-generated for: com.coloros.ocs.opencapabilityservice

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.coloros.ocs.opencapabilityservice"
