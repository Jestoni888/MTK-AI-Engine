#!/system/bin/sh
# Auto-generated for: com.oppo.ctautoregist

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oppo.ctautoregist"
