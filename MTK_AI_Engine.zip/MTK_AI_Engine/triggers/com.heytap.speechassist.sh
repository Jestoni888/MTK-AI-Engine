#!/system/bin/sh
# Auto-generated for: com.heytap.speechassist

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.heytap.speechassist"
