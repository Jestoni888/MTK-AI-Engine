#!/system/bin/sh
# Auto-generated for: com.netease.yysls

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.netease.yysls"
