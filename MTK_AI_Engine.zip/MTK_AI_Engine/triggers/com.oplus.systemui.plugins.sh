#!/system/bin/sh
# Auto-generated for: com.oplus.systemui.plugins

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oplus.systemui.plugins"
