#!/system/bin/sh
# Auto-generated for: com.oneplus.brickmode

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
