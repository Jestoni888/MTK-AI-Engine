#!/system/bin/sh
# Auto-generated for: com.oplus.phonenoareainquire

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
