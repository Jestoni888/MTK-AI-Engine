#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.oplus.bttestmode
echo "🔋 Powersaving: com.oplus.bttestmode"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.oplus.bttestmode"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.oplus.bttestmode"
