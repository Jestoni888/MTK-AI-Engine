#!/system/bin/sh
touch /sdcard/MTK_AI_Engine/enable_limiter
# 🔋 POWERSAVING MODE
# Auto-generated for: com.google.android.apps.docs
echo "🔋 Powersaving: com.google.android.apps.docs"
touch /sdcard/MTK_AI_Engine/enable_limiter

echo "🔋 Powersaving: com.google.android.apps.docs"
# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.google.android.apps.docs"
