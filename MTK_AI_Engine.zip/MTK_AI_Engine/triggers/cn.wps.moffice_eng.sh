#!/system/bin/sh
# Auto-generated for: cn.wps.moffice_eng

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: cn.wps.moffice_eng"
