#!/system/bin/sh
# Auto-generated for: com.android.ons

# 🔋 POWERSAVING MODE
touch /sdcard/MTK_AI_Engine/enable_limiter
echo "🔋 Powersaving: com.android.ons"
